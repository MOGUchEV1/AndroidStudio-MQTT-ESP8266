package com.example.test17022025;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MainActivity extends AppCompatActivity {

    private EditText passwordInput;
    private Button loginButton, ledButton;
    private MqttClient mqttClient;
    private boolean isLedOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация элементов интерфейса
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        ledButton = findViewById(R.id.ledButton);

        // Настройка MQTT
        setupMqtt();

        // Обработка входа
        loginButton.setOnClickListener(v -> {
            String password = passwordInput.getText().toString();
            if (password.equals("12345")) {
                ledButton.setVisibility(View.VISIBLE); // Показываем кнопку управления светодиодом
                Toast.makeText(this, "Пароль верный!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Неверный пароль!", Toast.LENGTH_SHORT).show();
            }
        });

        // Обработка кнопки светодиода
        ledButton.setOnClickListener(v -> {
            isLedOn = !isLedOn; // Переключаем состояние светодиода
            String message = isLedOn ? "ON" : "OFF"; // Сообщение для MQTT
            publishMqttMessage("led/control11", message); // Отправляем сообщение
            ledButton.setText(isLedOn ? "Выключить светодиод" : "Включить светодиод"); // Обновляем текст кнопки
        });
    }

    /**
     * Настройка MQTT-клиента.
     */
    private void setupMqtt() {
        try {
            // Подключение к MQTT-брокеру
            mqttClient = new MqttClient("tcp://mqtt.eclipseprojects.io:1883", MqttClient.generateClientId(), null);
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true); // Очистка сессии
            mqttClient.connect(options); // Подключение
        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка подключения к MQTT", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Отправка сообщения в MQTT-топик.
     *
     * @param topic   Топик, в который отправляется сообщение.
     * @param message Сообщение для отправки.
     */
    private void publishMqttMessage(String topic, String message) {
        try {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes());
            mqttClient.publish(topic, mqttMessage); // Публикация сообщения
        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка отправки сообщения", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            // Отключение от MQTT-брокера при закрытии приложения
            if (mqttClient != null && mqttClient.isConnected()) {
                mqttClient.disconnect();
            }
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}